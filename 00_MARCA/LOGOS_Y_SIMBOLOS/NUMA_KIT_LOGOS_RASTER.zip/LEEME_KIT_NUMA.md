# NUMA Creative Studio · Kit de recursos para Canva

**Estado:** recursos de marca preparados; NO es un Brand Kit oficial de Canva todavía.

## Colores
| Nombre | Hex |
|---|---|
| Carbón | `#0F1014` |
| Violeta | `#8C67F7` |
| Verde | `#2AA990` |
| Crema | `#F4F3EC` |
| Amarillo | `#FFD43A` |
| Coral | `#FD6333` |

## Fuentes según la lámina de referencia más reciente (12/11/2026)
- **Titulares:** Clash Grotesk Bold.
- **Textos:** DM Sans Regular / Medium.

**Nota:** los documentos anteriores mencionaban Clash Display y Manrope. Para evitar inconsistencias, el kit usa las fuentes de la lámina visual más reciente; confirmar que estén disponibles y licenciadas en el equipo Canva.

## Logotipo e icono
- `NUMA_logo_recorte_original_fondo_crema.png` es un recorte directo del **logotipo visible en la referencia que compartiste**, sin regeneración de IA.
- `NUMA_logo_negro_violeta_transparente.png` y otras dos variantes son **extracciones raster** del recorte anterior mediante eliminación del fondo. Mantienen la silueta de la referencia pero no sustituyen un SVG/AI original.
- `NUMA_simbolo_violeta_transparente.png` contiene el mini símbolo extraído de esa misma referencia.
- `NUMA_paleta_6_colores.png` es referencia visual para configurar los colores en Canva.

## Personalidad y estilo
Simple · Expresivo · Positivo · Flexible.
Formas orgánicas, flores/asteriscos, iconografía sólida redondeada, recortes, ilustraciones amigables, contraste y titulares marcados.

## Para crear el Brand Kit **oficial** en Canva
1. Dentro del equipo con acceso Pro, abrir **Marca** > **Kit de marca** > **Crear nuevo kit de marca** (o la opción equivalente).
2. Nombrar el kit `NUMA Creative Studio`.
3. Subir la variante original del logotipo y las versiones raster preparadas. Si hay un master SVG/AI, **preferirlo** a todas las versiones raster extraídas.
4. Añadir los seis colores HEX en el orden anterior.
5. Definir tipografías: `Clash Grotesk Bold` para títulos y `DM Sans` para texto, si están disponibles y la licencia lo permite.
6. Comprobar que el kit está en el **equipo correcto**, no solo en el espacio personal.

## Límites de verificación
La integración de Canva accesible desde ChatGPT puede ver y organizar diseños, pero **no expone una operación para crear un Brand Kit oficial ni seleccionar el equipo activo**. La entrada Pro debe verificarse dentro de Canva.

**Repositorio principal de documentación:** `juanesgir-alt/Proyecto-Numa` · no modificar el portafolio personal.
